import React from 'react';

const Header = () => {
  return (
    <header>
       <h1>Lucky Cat Bracelets</h1>
        <p>Your one-stop destination for amazing lucky cat bracelet.</p>
    </header>
  );
};

export default Header;
