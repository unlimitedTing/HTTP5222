const express = require("express");
const path = require("path"); // needed when setting up static/file paths
const { MongoClient, ObjectId } = require("mongodb");

const dbUrl = "mongodb://localhost:27017/testdb";
const client = new MongoClient(dbUrl);

// set up the Express app
const app = express();
const port = process.env.PORT || "8888";

// set up application template engine
app.set("views", path.join(__dirname, "views"));//the first views is the setting name
app.set("view engine", "pug");

// set up  folder for static files
app.use(express.static(path.join(__dirname, "public")));

// set up express parse form data
app.use(express.urlencoded({ extended: true }));
app.use(express.json())

// set up page paths
app.get("/", async (request, response) => {
    //response.status(200).send("Test");

    let links = await getLinks();
    response.render("index", { title: "Home", menu: links });
});

app.get("/about", async (request, response) => {
    let links = await getLinks();
    response.render("about", { title: "About", menu: links });
});

// path to link admin page
app.get("/admin/menu", async (request, response) => {
    let links = await getLinks();
    response.render("menu-list", { title: "Menu links admin", menu: links });
});

app.get("/admin/menu/add", async (request, response) => {
    let links = await getLinks();
    response.render("menu-add", { title: "Add menu link", menu: links });
});

// post to retrieve link data
app.post("/admin/menu/add/submit", async (request, response) => {
    //get form data
    let weight = request.body.weight; //get the value for field withname = "weight"
    let href = request.body.href; //request.body is form POST data
    let name = request.body.name;
    var newLink = { "weight": weight, "path": href, "name": name };
    await addLink(newLink);
    response.redirect("/admin/menu"); //redirect back to admin page
})

// path to delet link
app.get("/admin/menu/delete", async (request, response) => {
    //get linkId value
    let id = request.query.linkId;
    await deleteLink(id);
    response.redirect("/admin/menu");
});

// path to edit link
app.get("/admin/menu/edit", async (request, response) => {
    if (request.query.linkId) {
        let linkToEdit = await getSingleLink(request.query.linkId);
        let links = await getLinks();
        response.render("menu-edit", {
            title: "Edit menu link", menu: links,
            editLink: linkToEdit
        });
    } else {
        response.redirect("/admin/menu");
    }
});

app.post("/admin/menu/edit/submit", async (request, response) => {
    //get the _id and set it as a JSON object to be used for the filter
    let idFilter = { _id: new ObjectId(request.body.linkId) };
    //get weight/path/name form values and build a JSON object containing these (updated) values
    let link = {
    weight: request.body.weight,
    path: request.body.href,
    name: request.body.name,
    };
    //run editLink(idFilter, link) and await the result
    await editLink(idFilter,link);
    response.redirect("/admin/menu");
    });

// set up server listing
app.listen(port, () => {
    console.log(`Listening on http://localhost:${port}`);
});

// mongodb connection
async function connection() {
    db = client.db("testdb");
    return db;
}

async function getLinks() {
    db = await connection();
    var results = db.collection("menuLinks").find({});
    res = await results.toArray();
    return res;
}

async function addLink(link) {
    db = await connection();
    var status = await db.collection("menuLinks").insertOne(link);
    console.log("link added");
}

async function deleteLink(id) {
    db = await connection();
    const deleteId = { _id: new ObjectId(id) };
    const result = await db.collection("menuLinks").deleteOne(deleteId);
    if (result.deletedCount == 1)
        console.log("delete successful");
}

async function getSingleLink(id) {
    db = await connection();
    const editId = { _id: new ObjectId(id) };
    const result = await db.collection("menuLinks").findOne(editId);
    return result;
}

async function editLink(filter, link) {
    db = await connection();
    //create the update set { $set: <JSON document> }
    const update = { $set: link };
    //execute an updateOne() to update the link as selected via the filter
    const result = await db.collection("menuLinks").updateOne(filter, update);
    if(result.modifiedCount==1)
        console.log(`edit successful`);
    }